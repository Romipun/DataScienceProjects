pip install pandas

Python using Anaconda (latest version for windows)- (https://www.anaconda.com/distribution/)

import pandas as pd
import datetime as dt
import numpy as np
import plotly.express as px
import plotly.offline as py


[Netflix Original Films & IMDB Scores Datasets] - https://drive.google.com/file/d/1tzpJzbE5JKXshLGgNlnkieeCfzUtGKGq/view?usp=sharing